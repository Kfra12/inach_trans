<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include the PHPMailer classes
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {

    //extraction des variables
    extract($_POST);
    //verifions si les variables existent et ne sont pas vides 
    if (
        isset($nom) && $nom != "" &&
        isset($prenoms) && $prenoms != "" &&
        isset($email) && $email != "" &&
        isset($numero) && $numero != "" &&
        isset($lieu) && $lieu != "" &&
        isset($service) && $service != "" &&
        isset($message) && $message != ""
    ) {
        // Récupérer les données du formulaire
        $nom = $_POST['nom'];
        $prenoms = $_POST['prenoms'];
        $email = $_POST['email'];
        $numero = $_POST['numero'];
        $lieu = $_POST['lieu'];
        $service = $_POST['service'];
        $message = $_POST['message'];

        // Valider les données (ajoutez des validations supplémentaires au besoin)

        // Construire le corps du message
        $mailBody = "Nom: $nom\n";
        $mailBody .= "Prénoms: $prenoms\n";
        $mailBody .= "Email: $email\n";
        $mailBody .= "Téléphone: $numero\n";
        $mailBody .= "Adresse: $lieu\n";
        $mailBody .= "Service souhaité: $service\n";
        $mailBody .= "Message:\n$message";

        // Configuration de PHPMailer
        $mail = new PHPMailer(true);

        try {
            // Paramètres du serveur SMTP
            $mail->isSMTP();
            $mail->Host       = 'smtp.ionos.fr';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'contact@inach-transports.fr'; // Mettez votre adresse e-mail
            $mail->Password   = ''; // Mettez votre mot de passe (a configurer quand les infos seront transmises au developpeur pour terminer cette partie)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port       = 465;

            // Paramètres du message
            $mail->isHTML(false);
            $mail->setFrom($email, "$nom $prenoms");
            $mail->addAddress('contact@inach-transports.fr'); // Adresse e-mail de destination
            $mail->Subject = 'Nouvelle demande de service depuis INACH TRANSPORTS';
            $mail->Body    = $mailBody;

            // Envoyer l'e-mail
            $mail->send();

            $_SESSION['succes_message'] = 'Votre demande a été soumise avec succès. Nous vous contacterons bientôt.';
        } catch (Exception $e) {
            $info = 'Erreur lors de l\'envoi de la demande. Veuillez réessayer plus tard.';
        }
    } else {
        //si elle sont vides 
        $info = "Veuillez remplir tous les champs !";
    }
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inach Transports - L'express 7j/7</title>
    <link rel="shortcut icon" href="./assets/images/logo-inach.png" type="image/svg+xml">

    <link rel="stylesheet" href="./assets/css/contact.css">
</head>

<body>

    <div class="titre">
        <a href="index.html" class="logo">
            <img src="./assets/images/logo-inach.png" alt="">
            <h1>Inach Transports</h1>
        </a>
    </div>

    <h2>Pour toute demande de service, remplissez ce formulaire
    </h2>

    <?php
    //afficher message d'erreur
    if (isset($info)) { ?>
        <p class="request_message" style="color: red; text-transform: none;">
            <?= $info ?>
        </p>
    <?php
    }
    ?>

    <?php
    //afficher message de suucès
    if (isset($_SESSION['succes_message'])) { ?>
        <p class="request_message" style="color:green; text-transform: none;">
            <?= $_SESSION['succes_message'] ?>
        </p>
    <?php
    }
    ?>

    <section class="contact">

        <div class="part">

            <form action="" method="post">
                <label for="nom">Nom :</label>
                <input type="text" id="nom" name="nom"><br>

                <label for="prenoms">Prénoms :</label>
                <input type="text" id="prenoms" name="prenoms"><br>

                <label for="email">Email :</label>
                <input type="email" id="email" name="email"><br>

                <label for="numero">Téléphone :</label>
                <input type="tel" id="numero" name="numero"><br>

                <label for="lieu">Adresse :</label>
                <input type="text" id="lieu" name="lieu"><br>

                <label for="service">Service souhaité :</label>
                <select id="service" name="service">
                    <option value=""> </option>
                    <option value="Déménagement">Déménagement</option>
                    <option value="Transport privé">Transport privé</option>
                    <option value="Transport de marchandise">Transport de marchandise</option>
                    <option value="Fret maritime">Fret maritime</option>
                    <option value="Fret aérien">Fret aérien</option>
                    <option value="Stockage">Stockage</option>
                    <!-- Ajoutez d'autres options au besoin -->
                </select><br>

                <label for="message">Message :</label>
                <textarea cols="50" rows="10" id="message" name="message"></textarea><br>

                <input type="submit" value="Envoyer" name="submit">
            </form>
        </div>
    </section>



</body>


</html>